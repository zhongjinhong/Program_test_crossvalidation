git add .
git commit -m "modified from my macbook pro"
git push
